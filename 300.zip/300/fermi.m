function f = fermi(kt, de)
    % Fermi-Dirac distribution
    % kt: k*T, de: (e-mu)
    % Output: fermi function value
    % -maxe < ekt < maxe: f = 1/(exp(ekt) + 1)
    % ekt < -maxe: f = 1/(exp(-maxe) + 1) -> 1.0
    % ekt >  maxe: f = 1/(exp( maxe) + 1) -> 0.0

    maxexp = 100; % define maxexp to avoid numerical overflow
    ekt = de / kt; % calculate e/kT
    limited_ekt = sign(ekt) * min(abs(ekt), maxexp); % limit ekt within ±maxexp
    f = 1.0 ./ (1.0 + exp(limited_ekt)); % compute fermi function
end