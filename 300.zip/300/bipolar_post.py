# 读取文件，提取第二列数据（数值列），分别计算正值之和和负值之和，并计算比值（正值之和 / 负值绝对值之和）
file_path = 'bipolar.dat'

sum_pos = 0.0
sum_neg = 0.0

with open(file_path, 'r') as f:
    for line in f:
        parts = line.strip().split('\t')  # 按制表符分隔，确保第一列为标签，第二列为数值
        if len(parts) != 2:
            continue
        try:
            value = float(parts[1])
        except ValueError:
            continue
        if value >= 0:
            sum_pos += value
        else:
            sum_neg += value

ratio = abs(sum_neg)/ sum_pos # 正值之和 / 负值绝对值之和

print(f"正值之和: {sum_pos}")
print(f"负值之和: {sum_neg}")
print(f"比值 (正值之和 / 负值绝对值之和): {ratio}")
