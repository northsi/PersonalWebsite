import numpy as np

def trans_post():

    unitcharge = 1.60217733E-19
    bohr2ang = 0.52917721092
    ryd2ev  = 13.605698066
    timeunit = 4.8377687E-17
    t_cond_unit = 5393.09062574121
    kelvin2eV = 8.6173427909E-05
    cond_unit = unitcharge*1.0E10/(bohr2ang*ryd2ev*timeunit)
    seebeck_unit = kelvin2eV * 1.0E3

    # Read data from 'si.txt'
    ene_tdf = np.loadtxt('CoSi.tdf')  # Assuming 'si.txt' is whitespace-delimited

    # Extract energy values
    ene = ene_tdf[:, 0]
    ene = ene / ryd2ev
    nestep = len(ene)
    de = (ene[-1] - ene[0]) / (nestep - 1)
    # Extract TDF values
    tdf = ene_tdf[:, 2:8]
    tdf_t = ene_tdf[:, 8:14]

    # Parameters
    tp = 300
    tp = tp*kelvin2eV/ryd2ev

    ef = 16.9216
    ef = ef / ryd2ev

    # Vectorized computation of mfermi_deriv for all energy values
    mfermi_d = np.array([mfermi_deriv(tp, e - ef) for e in ene])

    cond = np.zeros(6)
    alpha = np.zeros(6)
    seebeck = np.zeros(6)
    kk_coef = np.zeros(6)

    # Element-wise multiplication
    for i in range(6):
        tdf_tmp = tdf[:,i] * mfermi_d  # Broadcasting in Python
        cond[i] = np.sum(tdf_tmp) * de
        tdf_tmp = tdf_tmp * (ene - ef)
        alpha[i] = - np.sum(tdf_tmp) * de
    # Compute cond by summing and multiplying by de
    

    for i in range(6):
        tdf_ttmp = mfermi_d * tdf_t[:,i]    
        seebeck[i] = - np.sum(tdf_ttmp) * ( de / tp )
        tdf_ttmp = tdf_ttmp * (ene - ef)
        kk_coef[i] = np.sum(tdf_ttmp) * ( de / tp )

    #print(kk_coef[0] * t_cond_unit)
    Seebeck_1, Kappa = extract_trans_coeff(tp, cond, seebeck, kk_coef, 6, alpha)

    #Seebeck_1 = Seebeck_1 * seebeck_unit
    #print('Seebeck =', Seebeck_1[0])
    cond = cond * cond_unit
    Kappa = Kappa * t_cond_unit
    return cond[0], Kappa[0]


def fermi(kt, de):
    """
    Fermi-Dirac distribution function
    kt: k * T
    de: (e - mu)
    Returns: Fermi function value
    """
    maxexp = 100  # Define maxexp to avoid numerical overflow
    ekt = de / kt
    limited_ekt = np.sign(ekt) * np.minimum(np.abs(ekt), maxexp)
    return 1.0 / (1.0 + np.exp(limited_ekt))


def mfermi_deriv(kt, de):
    """
    Compute derivative of Fermi-Dirac distribution with respect to E
    kt: k * T
    de: (e - mu)
    Returns: -df/dE
    """
    f_plus = fermi(kt, de)
    f_minus = fermi(kt, -de)
    return f_plus * f_minus / kt

def extract_trans_coeff(tmpr, cond, cond_seebeck, kk_coef, ncomp2, alpha):
    """
    Extract transport coefficients
    
    Args:
        tmpr (float): Temperature
        cond (np.ndarray): Conductivity tensor
        cond_seebeck (np.ndarray): Seebeck conductivity tensor
        kk_coef (np.ndarray): Coefficient tensor
        sys_2d (bool): Whether system is 2D
        ncomp2 (int): Number of components
        alpha (np.ndarray, optional): Alternative tensor
    
    Returns:
        tuple: Seebeck tensor and thermal conductivity tensor
    """
    t_cond_unit = 5393.09062574121
    # Convert rank-2 tensors to matrices
    c_tmp = tensor2matrix(cond)
    cs_tmp = tensor2matrix(cond_seebeck)
    
    # Determine thermal coefficient matrix
    tcs_tmp = tensor2matrix(alpha)

    c_aux = np.zeros((3, 3))
    s_tmp = np.zeros((3, 3))
    
        # 3D system processing
    c_aux = mat_inv3(c_tmp)
    s_tmp = np.matmul(c_aux, cs_tmp)
    c_aux = np.matmul(tcs_tmp, s_tmp)
    
    # Convert back to tensors
    seebeck = matrix2tensor(s_tmp, ncomp2)
    t_cond = matrix2tensor(c_aux, ncomp2)
    print('kappa_0 = ', kk_coef[0] * t_cond_unit)
    #print('sigma = ', cond[0])
    #print('condseebeck = ', cond_seebeck[0])
    #print('alpha = ', alpha[0])
    print('TsigmaS^2 = ', t_cond[0] * t_cond_unit) 
    # Final thermal conductivity calculation
    t_cond[:ncomp2] = kk_coef[:ncomp2] - t_cond[:ncomp2]

    return seebeck, t_cond

def mat_inv3(matrix):
    """3x3 matrix inversion (equivalent to Fortran mat_inv3)"""
    return np.linalg.inv(matrix)

def tensor2matrix(tensor):
    """
    Convert rank-2 tensor to matrix
    Equivalent to Fortran tensor2matrix subroutine
    
    Args:
        tensor (np.ndarray): Input tensor of size 6 or 9
    
    Returns:
        np.ndarray: 3x3 matrix representation
    """
    matrix = np.zeros((3, 3))
    n = 0
    
    for j in range(3):
        for i in range(j + 1):
            n += 1
            matrix[i, j] = tensor[n-1]
            
            # Symmetrize for 6-component tensor
            if i != j and len(tensor) == 6:
                matrix[j, i] = tensor[n-1]
    
    # Additional components for 9-component tensor
    if len(tensor) == 9:
        matrix[1, 0] = tensor[6]
        matrix[2, 0] = tensor[7]
        matrix[2, 1] = tensor[8]
    
    return matrix

def matrix2tensor(matrix, ncomp):
    """
    Convert matrix back to rank-2 tensor
    
    Args:
        matrix (np.ndarray): 3x3 input matrix
        ncomp (int): Number of tensor components (6 or 9)
    
    Returns:
        np.ndarray: Tensor representation
    """
    tensor = np.zeros(ncomp)
    n = 0
    
    for j in range(3):
        for i in range(j + 1):
            n += 1
            if ncomp == 6:
                # Average symmetrized components
                tensor[n-1] = (matrix[i, j] + matrix[j, i]) * 0.5
            else:
                tensor[n-1] = matrix[i, j]
    
    if ncomp == 9:
        tensor[6] = matrix[1, 0]
        tensor[7] = matrix[2, 0]
        tensor[8] = matrix[2, 1]
    
    return tensor


# Example usage
if __name__ == "__main__":
    cond, kk_coef = trans_post()
    print(f"Conductance: {cond, kk_coef}")