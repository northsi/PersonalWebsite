function df = mfermi_deriv(kt, de)
    % Compute derivative of Fermi-Dirac distribution with respect to E
    % kt: k*T, de: (e-mu)
    % Output: -df/dE
    % -maxe < ekt < maxe: df = f(ekt) * f(-ekt) / kt
    % otherwise: df = 0.0

    f_plus = fermi(kt, de); % fermi(de)
    f_minus = fermi(kt, -de); % fermi(-de)
    df = f_plus .* f_minus ./ kt; % derivative computation
end