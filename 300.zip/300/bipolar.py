import numpy as np
import matplotlib.pyplot as plt
from itertools import product

def calculate_polynomial_terms(a_values, b_values, c_values):
    t_cond_unit = 5393.09062574121
    # 用于存储结果的列表
    terms = []
    results_matrix = np.zeros((8, 8))
    # 使用itertools.product生成所有可能的组合
    Bipolar_p = 0
    Bipolar_n = 0
    for j, k in product(range(8), repeat=2):
        # 计算当前项的值
        term_value = 1/sum(a_values) * b_values[j] * c_values[k] * t_cond_unit
        results_matrix[j, k] = term_value

        if j != k:
            # 如果j不等于k，则将结果乘以2
            if term_value > 0:
                Bipolar_p = Bipolar_p + term_value
            else:
                Bipolar_n = Bipolar_n + term_value
        
        # 构建项的表达式
        term_expression = f"(1/sigma * b{j+1} * c{k+1})"
        
        # 将表达式和值添加到结果列表
        terms.append({
            'expression': term_expression,
            'value': term_value
        })
    print(f"Bipolar_p: {Bipolar_p}, Bipolar_n: {Bipolar_n}")
    return terms, results_matrix

def plot_heatmap(matrix):
    plt.rcParams['font.family'] = 'Arial'
    plt.figure(figsize=(10, 8))
    # 反转矩阵的行顺序
    matrix = matrix[::-1]
    plt.imshow(matrix, cmap='RdYlGn', interpolation='nearest', vmin=-0.2, vmax=0.2)
    cbar = plt.colorbar(pad=0.01)
    cbar.ax.tick_params(labelsize=24)
    # 设置刻度标签
    plt.xticks(range(8), [f'{i+1}' for i in range(8)], fontsize=34)
    plt.yticks(range(8), [f'{8-i}' for i in range(8)], fontsize=34)
    
    plt.xlabel('Band Index', fontsize=40)
    plt.ylabel('Band Index', fontsize=40)
    plt.tight_layout()  # 调整布局，避免标签重叠
    plt.savefig("Desktop\\CoSi\\300\\bipolar.png", dpi=600)

# 示例使用:
if __name__ == "__main__":
    # 示例值,您可以根据需要修改这些值
    a_values = [0.0022637195855327273, 0.0038742364719401502, 0.029127611589586908, 0.032533834062538985, 0.03688692734027435, 0.03347649237111548, 0.034700104062656216, 0.03159608301640224]  # a1到a8的值
    b_values = [0.005538559764028121, 0.0078072259206405925, 0.03427946138531823, 0.03543826252320671, -0.06768673930216225, -0.06197204544292312, -0.06435664519741224, -0.060239346446342094]  # b1到b8的值
    c_values = [1.0473483708756735e-05, 1.5084797898734746e-05, 6.425851513158049e-05, 6.641685972297096e-05, -0.00011437939534919638, -0.00010530581935056943, -0.00010371053211386207, -9.642391369110145e-05]  # c1到c8的值
    
    # 计算所有项
    [results,results_matrix]  = calculate_polynomial_terms(a_values, b_values, c_values)
    
    with open("bipolar.dat", "w") as f:
        for term in results:
            f.write(f"{term['expression']}\t{term['value']}\n")
    
    # 计算总和
    total = sum(term['value'] for term in results)
    print(f"\n所有项的和: {total}")
    plot_heatmap(results_matrix)