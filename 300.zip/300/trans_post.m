function trans_post()
format long
ene_tdf = readmatrix('si.txt');

ene = ene_tdf(:,1);
nestep = length(ene);
de = (ene(nestep) - ene(1)) / (nestep - 1)

tdf = ene_tdf(:,3);

tp = 300;
ef = 6.5504824219;

% Vectorized computation of mfermi_deriv for all energy values
for i = 1:nestep
mfermi_d(i) = mfermi_deriv(tp, ene(i) - ef); % Size: same as ene
end

% Element-wise multiplication for entire matrix
tdf_tmp = tdf * mfermi_d; % Broadcasting in MATLAB

% Compute cond by summing over rows (dim = 2) and multiplying by de
cond = tdf_tmp * de

end